░       ░░░        ░░░      ░░░       ░░░        ░░        ░░  ░░░░  ░░░      ░░░  ░░░░  ░░       ░░░        ░
▒  ▒▒▒▒  ▒▒  ▒▒▒▒▒▒▒▒  ▒▒▒▒  ▒▒  ▒▒▒▒  ▒▒▒▒▒  ▒▒▒▒▒  ▒▒▒▒▒▒▒▒▒  ▒▒  ▒▒▒  ▒▒▒▒▒▒▒▒  ▒▒▒▒  ▒▒  ▒▒▒▒  ▒▒  ▒▒▒▒▒▒▒
▓       ▓▓▓      ▓▓▓▓  ▓▓▓▓  ▓▓  ▓▓▓▓  ▓▓▓▓▓  ▓▓▓▓▓      ▓▓▓▓▓▓    ▓▓▓▓▓      ▓▓▓  ▓▓▓▓  ▓▓       ▓▓▓      ▓▓▓
█  ███  ███  ████████        ██  ████  █████  █████  ███████████  ███████████  ██  ████  ██  ███  ███  ███████
█  ████  ██        ██  ████  ██       ███        ██  ███████████  ██████      ████      ███  ████  ██  ███████

										+= READIFY-SURF v.0.0.1 =+
							                   
	+ readify-surf is a continuation of a prior, more simple tool "readify-click". 
		readify-surf allows you to toggle viewing the current page in readify.me, allowing you to 
		click links, and thus, traverse the internet without the annoyance of ads, photos, javascript,
		etc. . . the tool also adds an option when right-clicking a link to "open in readify.me" --
		useful for opening a page that you plan on bookmarking / sharing / sending to linkshare pages
		
		
		
											MIT License

									Copyright (c) 2025 READIFY-SURF

				Permission is hereby granted, free of charge, to any person obtaining a copy
				of this software and associated documentation files (the "Software"), to deal
				in the Software without restriction, including without limitation the rights
				to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
				copies of the Software, and to permit persons to whom the Software is
				furnished to do so, subject to the following conditions:

				The above copyright notice and this permission notice shall be included in all
				copies or substantial portions of the Software.

				THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
				IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
				FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
				AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
				LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
				OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
				SOFTWARE.
		
		
		
		
	CHANGELOG:
	
		- EXPANDED UPON READIFY-CLICK
		- V 0.0.1 IS MADE!
		
	READIFY-SURF IS CURRENTLY IN ALPHA! IT WILL CONTINUE TO BE VIEWED AS SUCH UNTIL IT IS ADDED TO THE
		MOZILLA ADDONS MANAGER, ALLOWING YOU TO INSTALL IT THE NORMAL WAY. UNTIL THEN:
			- GO TO about:debugging
			- CLICK "THIS FIREFOX" -> "LOAD TEMPORARY ADD-ON"
			- SELECT THE MANIFEST.JSON FILE FROM "READIFY-SURF" DIRECTORY
		- I WOULD IMAGINE THAT IF YOU CLEAR CACHE THAT YOU PROBABY HAVE TO REINSTALL THE ADDON WHEN 
				DOING IT THIS WAY. IDK. TRY IT OUT.